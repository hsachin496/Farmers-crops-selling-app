

	<style>
	.avatar {
    vertical-align: middle;
    width: 150px;
    height: 150px;
    border-radius: 50%;
}
	</style>


    <?php

	include_once('dealernavbar.php');
	//session_start();
	$fid=$_SESSION['mobno'];
	
	
	//$fname=$_SESSION['fname'];
	//$funame=$_SESSION['funame'];


	include_once('db.php');
	$sql="select img_file from registration where mobno='$fid'";
	$res=execute( $sql );

	$row=$res->fetch_object();

	$fimg=$row->img_file;
	
	


	
	
	
	echo "<div align=left class='container' ><center><br/><img src='images/$fimg' class='avatar img-fluid img-responsive img-circle' /><br><a href=upload.php class='btn btn-primary' ><br/>Change Picture</a></center></div>";

	
	
	

	
	

	

	?>