<?php

	
	session_start();
	unset( $_SESSION['mobno'] );
	header('Location:index.php');

	?>