
   <?php
		
	include_once('farmernavbar.php');
	//session_start();
	$fid=$_SESSION['mobno'];

	
	
	
     
	include_once('db.php');	
	
	$sino=$_REQUEST['sino'];

	
	//echo $sino;


	$sql="select * from crops where( fid='$fid' and sino=$sino )";
	$res=execute($sql);
	$row=$res->fetch_object();
	

	$acname=array("Rice","Jower","Ground nut","Areca nut","Tomato","Green chilli");

	$aquality=array("High","Medium","Low");
	
		

	
	
	?>


	<html>


	<head>

	
	<h2 class="text-success font-bold"><b>Edit Crop Details Form</b></h2>
	
	
	<style>
	input[type='text'],select{
	
	width:150px;
	height:33px;
	border:1px solid green;
	font-size:bold;
	}
	</style>
	
	</head>

	<body>

	<div class="container">
	
	<form name="f1" action="updatecrop.php" method="post">

	<input type="hidden" value=<?php echo $sino; ?> name="sino" />

	<table align=center class="table">

	<tr>
	<td>
	Crop Name
	</td>
	<td>
	<select name="cropname" id="Choose Crop name" >
	<?php

	for($i=0; $i<sizeof($acname); $i++)
	{
	?>
	
	<option value="<?php echo $acname[$i]; ?>" <?php if( $row->cropname==$acname[$i] ) { ?> selected <?php } ?> > <?php echo $acname[$i]; ?> </option>

	<?php
	}
	?>

	</select>

	</td>
	</tr>


	<tr>
	<td>
	Choose Quality
	</td>
	<td>
	
	<select name="quality" id="Choose Quality" >
	
	<?php

	for($i=0; $i<sizeof($aquality); $i++ )
	{
	?>

	<option value=<?php echo $aquality[$i]; ?>  <?php if($aquality[$i]==$row->quality){?> selected <?php } ?>  > <?php echo $aquality[$i]; ?> </option>
	
	<?php
	}
	?>
	

	</select>
	
	</td>

	</tr>



	<tr>
	<td>
	Quantity
	</td>
	<td>
	<input type="text" name="qnt" id="Quantity" value=<?php echo $row->qnt; ?> />

	&nbsp;&nbsp;&nbsp;
	<select name="cunit" >
	<option value="kw">Kwintols</option>
	<option value="kg">Kilo Grams</option>
	</select>


	</td>
	</tr>


	<tr>
	<td>
	Estimated Price
	</td>
	<td>
	<input type="text" name="estprice" id="Estimated Price" value=<?php echo $row->estprice; ?> />


	&nbsp;

	<select  name="punit" >
	<option value="kw">Per Kwintol</option>
	<option value="kg">Per KG</option>
	</select>
	</td>
	</tr>


	<tr>
	<td colspan=2 align=center>
	<input type="submit" value=" UPDATE " onclick="" class="btn btn-primary" />
	</td>
	</tr>

	

	
	</table>

	</div>



	</form>

	</body>


	</html>



	