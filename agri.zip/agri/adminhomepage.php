<?php

include_once('adminnavbar.php');

?>

<div class="container" style="" >
<center>
<img src="img/dashboard.png" class="img img-responsive" />
<h2 class="text-danger">Welcome to Admin Panel</h2>
</center>
</div>