<?php

	include_once('dealernavbar.php');

?>

<div style="height: 90vh" class="text-primary" >
        <div class="flex-center flex-column" style="">
		
			<img src="img/dealerr.jpg" class="img-fluid img-circle" />
            <h1 class="animated fadeIn mb-4"><center>Welcome </br> To </center>  Kurshi Mitra App</h1>

            <h5 class="animated fadeIn mb-3">Thank you for using our product. We're glad you're with us.</h5>

            <p class="animated fadeIn text-muted">Kurshi Mitra Team</p>
        </div>
    </div>