<?php
	
	include_once('farmernavbar.php');
?>
      
	<div style="height: 90vh">
        <div class="flex-center flex-column" style="">
		
			<img src="img/farmerbanner.jpg" class="img-fluid img-circle" />
            <h4 class="text-danger"><center>Welcome To  Kurshi Mitra </center></h4>

            
			<center><h5 class="">Thank you for using our product. We're glad you're with us.</h5></center>

            <p class="animated fadeIn text-muted">Kurshi Mitra Team</p>
        </div>
    </div>